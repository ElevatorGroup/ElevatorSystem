package cn.elevator.service.building;



import cn.elevator.entity.Building;

public interface BuildingService {
	public Building getBuidingById(Integer buildingId)throws Exception;
}
