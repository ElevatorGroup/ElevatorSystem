package cn.elevator.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BuildingController {
	

}
